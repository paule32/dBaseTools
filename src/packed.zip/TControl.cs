﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace DBaseButtonOCX
{
    [ComVisible(true)]
    [Guid("fc6a580b-ca2e-4068-9ad3-b64cb4001d9c")]
    [ProgId("DBase.TControl")]
    [ClassInterface(ClassInterfaceType.None)]
    public partial class TControl: UserControl
    {
        public TControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClickButton();
        }
    }
}
