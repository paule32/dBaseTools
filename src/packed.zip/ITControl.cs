﻿using System.Runtime.InteropServices;

namespace DBaseButtonOCX
{
    //[ComVisible(true)]
    //[Guid("fc6a580b-ca2e-4068-9ad3-b64cb4001d9c")]
    public interface ITControl
    {
        void ClickButton();
    }
}
